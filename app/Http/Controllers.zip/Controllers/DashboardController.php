<?php

namespace App\Http\Controllers;

use App\Models\Member;
use App\Models\District;
use App\Models\Clan;
use App\Models\Town;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        if ($user->hasRole('admin')) {
            return $this->admin();
        } elseif ($user->hasRole('manager')) {
            return $this->manager();
        }

        // Default dashboard for users without specific roles
        return redirect()->route('home');
    }

    public function admin()
    {
        $stats = [
            'total_members' => Member::count(),
            'pending_members' => Member::where('status', 'pending')->count(),
            'approved_members' => Member::where('status', 'approved')->count(),
            'rejected_members' => Member::where('status', 'rejected')->count(),
            'total_districts' => District::count(),
            'total_clans' => Clan::count(),
            'total_towns' => Town::count(),
            'first_time_voters' => Member::whereRaw('current_age < 18 AND age_2029 >= 18')->count(),
        ];

        // Basic Statistics
        $totalMembers = Member::count();
        $newMembersLast30Days = Member::where('created_at', '>=', now()->subDays(30))->count();
        $previousMembers = $totalMembers - $newMembersLast30Days;
        $memberGrowthPercent = $previousMembers > 0 ? round(($newMembersLast30Days / $previousMembers) * 100, 1) : ($totalMembers > 0 ? 100 : 0);

        // Districts
        $totalDistricts = District::count();
        $towns = Town::withCount('members')->get();
        $districts = District::withCount('members')->get();

        // Clans (max 6)
        $registeredClans = Clan::count();
        $clanPercentage = 6 > 0 ? round(($registeredClans / 6) * 100, 1) : 0;
        $clans = Clan::withCount('members')->get();

        // Towns (max 50)
        $registeredTowns = Town::count();
        $townGrowthPercent = 50 > 0 ? round(($registeredTowns / 50) * 100, 1) : 0;
        $towns = Town::withCount('members')->get();

        // Towns with member counts (all towns, even with 0 members)
        $towns = Town::leftJoin('members', 'members.town_id', '=', 'towns.id')->leftJoin('districts', 'districts.id', '=', 'towns.district_id')->select('towns.id', 'towns.name', 'districts.name as district_name', DB::raw('COUNT(members.id) as members_count'))->groupBy('towns.id', 'towns.name', 'districts.name')->orderBy('districts.name')->orderBy('towns.name')->get();

        // Gender breakdown
        $genderData = Member::select('gender', DB::raw('count(*) as count'))->groupBy('gender')->get();

        // District breakdown
        $districtData = Member::select('districts.name', DB::raw('count(*) as count'))->join('districts', 'members.district_id', '=', 'districts.id')->groupBy('districts.name')->get();

        // WhatsApp Statistics
        $whatsappCount = Member::where('whatsapp_primary', true)->orWhere('whatsapp_secondary', true)->count();

        // Occupation Statistics
        $occupationStats = Member::selectRaw('occupation, COUNT(*) as count')->whereNotNull('occupation')->groupBy('occupation')->orderByRaw('count DESC')->limit(10)->get();

        // Age groups
        $ageGroups = [
            '15-17' => Member::whereBetween('current_age', [15, 17])->count(),
            '18-25' => Member::whereBetween('current_age', [18, 25])->count(),
            '26-35' => Member::whereBetween('current_age', [26, 35])->count(),
            '36-45' => Member::whereBetween('current_age', [36, 45])->count(),
            '46-55' => Member::whereBetween('current_age', [46, 55])->count(),
            '56+' => Member::where('current_age', '>', 55)->count(),
        ];

        // Monthly registration trend
        $monthlyRegistrations = Member::select(DB::raw('DATE_FORMAT(created_at, "%Y-%m") as month'), DB::raw('count(*) as count'))->groupBy('month')->orderBy('month', 'desc')->limit(12)->get();

        // Volunteer statistics
        $volunteerStats = [
            'willing_to_volunteer' => Member::where('willing_to_volunteer', true)->count(),
            'willing_to_lead' => Member::where('willing_to_lead', true)->count(),
        ];

        return view('dashboards.admin', compact('totalMembers', 'clans', 'stats', 'whatsappCount', 'occupationStats', 'genderData', 'districtData', 'ageGroups', 'registeredClans', 'registeredTowns', 'towns', 'monthlyRegistrations', 'volunteerStats', 'totalDistricts', 'districts'));
    }

    public function manager()
    {
        $stats = [
            'total_members' => Member::count(),
            'pending_members' => 0, // REQUIRED for shared views
            'approved_members' => Member::where('status', 'approved')->count(),
            'rejected_members' => 0,
            'total_districts' => District::count(),
            'total_towns' => Town::count(),
        ];

        $recentMembers = Member::with(['district', 'clan', 'town'])
            ->orderBy('created_at', 'desc')
            ->limit(10)
            ->get();

        return view('dashboards.manager', compact('stats', 'recentMembers'));
    }
}
